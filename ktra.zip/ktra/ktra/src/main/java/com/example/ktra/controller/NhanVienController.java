package com.example.ktra.controller;

import com.example.ktra.entity.NhanVien;
import com.example.ktra.entity.PhongBan;
import com.example.ktra.service.NhanVienService;
import com.example.ktra.service.PhongBanService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/nhanvien")
@RequiredArgsConstructor
public class NhanVienController {

    private final NhanVienService nhanVienService;
    private final PhongBanService phongBanService;

    @GetMapping
    public String listNhanVien(Model model, @RequestParam(defaultValue = "0") int page) {
        Pageable pageable = PageRequest.of(page, 5); // 5 nhân viên mỗi trang
        Page<NhanVien> nhanVienPage = nhanVienService.getAllNhanVien(pageable);
        model.addAttribute("nhanVienPage", nhanVienPage);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", nhanVienPage.getTotalPages());
        return "nhanvien/list";
    }

    @GetMapping("/add")
    public String addNhanVienForm(Model model) {
        NhanVien nhanVien = new NhanVien();
        List<PhongBan> phongBanList = phongBanService.getAllPhongBan();
        model.addAttribute("nhanVien", nhanVien);
        model.addAttribute("phongBanList", phongBanList);
        return "nhanvien/add";
    }

    @PostMapping("/add")
    public String addNhanVien(@ModelAttribute NhanVien nhanVien){
        nhanVienService.saveNhanVien(nhanVien);
        return "redirect:/nhanvien";
    }

    @GetMapping("/edit/{maNV}")
    public String editNhanVienForm(@PathVariable String maNV, Model model) {
        NhanVien nhanVien = nhanVienService.getNhanVienById(maNV);
        List<PhongBan> phongBanList = phongBanService.getAllPhongBan();
        model.addAttribute("nhanVien", nhanVien);
        model.addAttribute("phongBanList", phongBanList);
        return "nhanvien/edit";
    }

    @PostMapping("/edit")
    public String editNhanVien(@ModelAttribute NhanVien nhanVien) {
        nhanVienService.saveNhanVien(nhanVien);
        return "redirect:/nhanvien";
    }

    @GetMapping("/delete/{maNV}")
    public String deleteNhanVien(@PathVariable String maNV) {
        nhanVienService.deleteNhanVienById(maNV);
        return "redirect:/nhanvien";
    }
}

