package com.example.ktra.service;

import com.example.ktra.entity.NhanVien;
import com.example.ktra.Repository.NhanVienRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class NhanVienService {
    private final NhanVienRepository nhanVienRepository;

    public Page<NhanVien> getAllNhanVien(Pageable pageable) {
        return nhanVienRepository.findAll(pageable);
    }

    public NhanVien getNhanVienById(String maNV) {
        return nhanVienRepository.findById(maNV).orElse(null);
    }

    public NhanVien saveNhanVien(NhanVien nhanVien) {
        return nhanVienRepository.save(nhanVien);
    }

    public void deleteNhanVienById(String maNV) {
        nhanVienRepository.deleteById(maNV);
    }
}
