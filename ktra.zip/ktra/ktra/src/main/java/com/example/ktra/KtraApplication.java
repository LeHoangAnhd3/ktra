package com.example.ktra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KtraApplication {

	public static void main(String[] args) {
		SpringApplication.run(KtraApplication.class, args);
	}

}
