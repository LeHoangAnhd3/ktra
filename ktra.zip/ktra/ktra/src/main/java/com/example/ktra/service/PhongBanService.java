package com.example.ktra.service;

import com.example.ktra.entity.PhongBan;
import com.example.ktra.Repository.PhongBanRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PhongBanService {
    private final PhongBanRepository phongBanRepository;
    public List<PhongBan> getAllPhongBan() {
        return phongBanRepository.findAll();
    }
}

