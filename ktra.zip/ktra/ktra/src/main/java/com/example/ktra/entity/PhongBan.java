package com.example.ktra.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;

@Entity
@Getter
@Setter

@NoArgsConstructor
@RequiredArgsConstructor
public class PhongBan {
    @Id
    @NonNull
    private String maPhong;
    @NonNull
    private String tenPhong;
}
