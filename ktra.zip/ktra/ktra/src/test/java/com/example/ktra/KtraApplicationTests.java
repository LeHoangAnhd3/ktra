package com.example.ktra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KtraApplicationTests {

	@Test
	void contextLoads() {
	}

}
